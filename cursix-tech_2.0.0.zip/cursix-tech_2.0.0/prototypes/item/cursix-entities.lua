data:extend(
{
  {
    type = "item",
    name = "cursix-beacon",
    icon = "__cursix-tech__/graphics/icons/cursix-beacon.png",
	  icon_size = 32,
    subgroup = "module",
    order = "a[beacon]-a[cursix]",
    place_result = "cursix-beacon",
    stack_size = 50
  },
}
)
