data:extend(
  {
    {
      type = "equipment-grid",
      name = "cursix-equipment-grid-12",
      width = 12,
      height = 12,
      equipment_categories = { "armor" }
    }
  }
)
