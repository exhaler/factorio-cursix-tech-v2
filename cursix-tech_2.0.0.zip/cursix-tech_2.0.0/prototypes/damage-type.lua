data:extend(
{
  {
    type = "damage-type",
    name = "plasma"
  },
}
)